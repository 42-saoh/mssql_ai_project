package com.pec.ppm.workflow.draft.service;

import java.util.List;

import com.pec.ppm.workflow.draft.model.GetInspItemsCdDTO;

/**
 * GetInspItemsCd 서비스 초안.
 * 근거 보강 필요: transaction boundary 는 evidence 확정 후 보강한다.
 */
public interface GetInspItemsCdService {

    /**
     * GetInspItemsCd 목록을 조회한다.
     *
     * @param condition 조회 조건 DTO
     * @return GetInspItemsCd 목록
     */
    List<GetInspItemsCdDTO> retrieveGetInspItemsCdList(GetInspItemsCdDTO condition);
}
