package com.pec.ppm.workflow.draft.model;

import java.time.LocalDateTime;

/**
 * GetInspItemsCd DTO 초안.
 * evidence: dbo.GetInspItemsCd, dbo.PEX_INSP_ITEMS, dbo.GetInspItemsCd, PEX_INSP_ITEMS, dbo.PEX_INSP_ITEMS, 3a0ef37e8c70b1fc8b496d9fd3352a820a1ca3c7ba6cb67d8d77d007eac44820
 * 근거 보강 필요: 필드/타입은 metadata evidence 기준 초안이다.
 */
public class GetInspItemsCdDTO {

    /** 검사항목코드 */
    private String inspItemsCd;

    /** 검사항목분류코드 */
    private String inspItemsClassCd;

    /** 검사항목명 */
    private String inspItemsNm;

    /** 검사항목설명 */
    private String inspItemsDesc;

    /** 검사항목구분코드 */
    private String inspItemsDivCd;

    /** 상위검사항목코드 */
    private String supiInspItemsCd;

    /** 입회검사여부 */
    private String wihInspYn;

    /** 검사항목일련번호 */
    private Integer inspItemsSeqNo;

    /** 유효여부 */
    private String vldYn;

    /** 생성사용자아이디 */
    private String creUsrId;

    /** 생성일시 */
    private LocalDateTime creDtm;

    /** 수정사용자아이디 */
    private String updUsrId;

    /** 수정일시 */
    private LocalDateTime updDtm;

    public String getInspItemsCd() {
        return inspItemsCd;
    }

    public void setInspItemsCd(String inspItemsCd) {
        this.inspItemsCd = inspItemsCd;
    }

    public String getInspItemsClassCd() {
        return inspItemsClassCd;
    }

    public void setInspItemsClassCd(String inspItemsClassCd) {
        this.inspItemsClassCd = inspItemsClassCd;
    }

    public String getInspItemsNm() {
        return inspItemsNm;
    }

    public void setInspItemsNm(String inspItemsNm) {
        this.inspItemsNm = inspItemsNm;
    }

    public String getInspItemsDesc() {
        return inspItemsDesc;
    }

    public void setInspItemsDesc(String inspItemsDesc) {
        this.inspItemsDesc = inspItemsDesc;
    }

    public String getInspItemsDivCd() {
        return inspItemsDivCd;
    }

    public void setInspItemsDivCd(String inspItemsDivCd) {
        this.inspItemsDivCd = inspItemsDivCd;
    }

    public String getSupiInspItemsCd() {
        return supiInspItemsCd;
    }

    public void setSupiInspItemsCd(String supiInspItemsCd) {
        this.supiInspItemsCd = supiInspItemsCd;
    }

    public String getWihInspYn() {
        return wihInspYn;
    }

    public void setWihInspYn(String wihInspYn) {
        this.wihInspYn = wihInspYn;
    }

    public Integer getInspItemsSeqNo() {
        return inspItemsSeqNo;
    }

    public void setInspItemsSeqNo(Integer inspItemsSeqNo) {
        this.inspItemsSeqNo = inspItemsSeqNo;
    }

    public String getVldYn() {
        return vldYn;
    }

    public void setVldYn(String vldYn) {
        this.vldYn = vldYn;
    }

    public String getCreUsrId() {
        return creUsrId;
    }

    public void setCreUsrId(String creUsrId) {
        this.creUsrId = creUsrId;
    }

    public LocalDateTime getCreDtm() {
        return creDtm;
    }

    public void setCreDtm(LocalDateTime creDtm) {
        this.creDtm = creDtm;
    }

    public String getUpdUsrId() {
        return updUsrId;
    }

    public void setUpdUsrId(String updUsrId) {
        this.updUsrId = updUsrId;
    }

    public LocalDateTime getUpdDtm() {
        return updDtm;
    }

    public void setUpdDtm(LocalDateTime updDtm) {
        this.updDtm = updDtm;
    }
}
