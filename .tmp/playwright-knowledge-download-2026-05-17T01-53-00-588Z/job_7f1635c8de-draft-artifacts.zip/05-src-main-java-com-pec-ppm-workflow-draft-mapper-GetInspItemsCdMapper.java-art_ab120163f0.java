package com.pec.ppm.workflow.draft.mapper;

import java.util.List;

import com.pec.ppm.workflow.draft.model.GetInspItemsCdDTO;

/**
 * GetInspItemsCd Mapper 초안.
 * 근거 보강 필요: Mapper XML namespace/sql id 와 함께 검토한다.
 */
public interface GetInspItemsCdMapper {

    /**
     * GetInspItemsCd 목록을 조회한다.
     *
     * @param condition 조회 조건 DTO
     * @return GetInspItemsCd 목록
     */
    List<GetInspItemsCdDTO> selectGetInspItemsCdList(GetInspItemsCdDTO condition);
}
