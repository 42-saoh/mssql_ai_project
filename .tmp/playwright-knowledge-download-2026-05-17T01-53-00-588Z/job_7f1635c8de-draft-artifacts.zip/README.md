# Draft artifacts for job_7f1635c8de

These files are draft outputs from the MSSQL Agent Portal.
They contain sanitized draft artifact contents for offline reading and handoff.
