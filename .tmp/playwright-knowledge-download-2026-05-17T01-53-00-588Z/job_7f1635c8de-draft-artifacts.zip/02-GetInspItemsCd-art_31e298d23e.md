# GetInspItemsCd 의존성 보고서 초안

## dependency_summary
- 상태: 초안(`DRAFT`)
- 근거 보강 필요: 호출 그래프는 canonical dependency resolver 결과로 확정
- rootProcedure: `dbo.GetInspItemsCd`
- dependencyClosureTool: `get_dependency_closure`
- dependencySnapshot: `live:ppm:2026-05-17T01:07:06Z`
- closureNodes: 2
- closureEdges: 1
- unresolvedReviewRequired: 0

## dependency_table
| 유형 | 객체 | 근거 |
|---|---|---|
| 저장 프로시저 | `dbo.GetInspItemsCd` | COLLECTED |
| 테이블 | `dbo.PEX_INSP_ITEMS` | MSSQL MCP table schema metadata 근거입니다. |
| 의존성 근거 | `dbo.GetInspItemsCd` | MSSQL MCP dependency closure 근거입니다. |
| 의존성 근거 | `PEX_INSP_ITEMS` | MSSQL MCP dependency closure 근거입니다. |
| 의존성 근거 | `dbo.PEX_INSP_ITEMS` | MSSQL MCP dependency closure 근거입니다. |
| LLM 추론 | `3a0ef37e8c70b1fc8b496d9fd3352a820a1ca3c7ba6cb67d8d77d007eac44820` | 3a0ef37e8c70b1fc8b496d9fd3352a820a1ca3c7ba6cb67d8d77d007eac44820 |

## dependency_closure_evidence
| 상태 | 객체 | 유형 | 확인 전략 |
|---|---|---|---|
| CONFIRMED | `/PPM/dbo/PEX_INSP_ITEMS/TABLE` | REFERENCE | REFERENCED_ID |

<!-- section:dependency_inventory -->
## 의존성 상세 목록
- source: migrationGuide.dependency_inventory
### 확인됨
| 유형 | 이름 | 참조 방식 | 근거 | 비고 |
|---|---|---|---|---|
| reference | `|PPM|dbo|PEX_INSP_ITEMS|TABLE` | REFERENCED_ID | PEX_INSP_ITEMS, dbo.PEX_INSP_ITEMS | REFERENCED_ID CATALOG_OBJECT_ID |
| table | `PEX_INSP_ITEMS` | static parser | static.analysis.migration_guide | 정적 parser에서 확인한 참조입니다.  |

### 근거 보강 필요
| 유형 | 이름/후보 | 불확실한 이유 | 다음 추출 항목 | 비고 |
|---|---|---|---|---|
| 없음 | 없음 | 없음 | 없음 | 근거 보강이 필요한 의존성 후보가 없습니다. |

<!-- section:dml_impact_matrix -->
## 테이블별 DML 영향
- source: migrationGuide.dml_matrix
| 테이블 | SELECT | INSERT | UPDATE | DELETE | MERGE | 키/조인/조건 요약 | 중요 컬럼/패턴 | 근거 |
|---|---|---|---|---|---|---|---|---|
| `PEX_INSP_ITEMS` | Y |  |  |  |  | 근거 보강 필요: predicate/key 추출은 추가 근거 확인이 필요합니다. | 근거 보강 필요: 중요 컬럼 패턴은 LLM 출력만으로 추론하지 않습니다. | static.dml.select.pex_insp_items |

| 작업 | 대상 | 단계 | 상태 | evidenceRefs | 영향 |
|---|---|---|---|---|---|
| SELECT | `PEX_INSP_ITEMS` | static_dml_scan | Confirmed | static.dml.select.pex_insp_items | PEX_INSP_ITEMS에 대한 SELECT 참조를 감지했습니다. |

<!-- section:call_flow -->
## 분기별 호출 흐름
- source: migrationGuide.call_flow
- 입력:
  - 메타데이터에서 확인한 procedure 파라미터입니다.
- 분기: branch_dml_1 phase=static_dml_scan evidenceRefs=static.dml.select.pex_insp_items 조건=PEX_INSP_ITEMS에 대한 SELECT 참조를 감지했습니다.
  - 동작: SELECT dependency=PEX_INSP_ITEMS evidenceRefs=static.dml.select.pex_insp_items
- 결과 / 출력:
  - 결과 shape 후보는 appendix mappings에 렌더링됩니다.
- 오류 처리: 근거 보강 필요: 정상/예외/resource cleanup 분기를 확인합니다.

<!-- section:evidence_assumptions_review -->
## 근거 및 품질 caveat
- evidenceRefs:
  - id=ev_metadata_1 type=MSSQL_METADATA objectRef=dbo.GetInspItemsCd locator=sys.sql_modules
  - id=ev_metadata_2 type=MSSQL_METADATA objectRef=dbo.GetInspItemsCd locator=sys.parameters
  - id=ev_metadata_3 type=MSSQL_METADATA objectRef=dbo.GetInspItemsCd locator=sys.sql_expression_dependencies
  - id=ev_metadata_4 type=MSSQL_METADATA objectRef=dbo.GetInspItemsCd locator=sys.sql_modules:hash-pattern
  - id=ev_metadata_5 type=MSSQL_METADATA objectRef=dbo.GetInspItemsCd locator=sys.objects
  - id=ev_metadata_6 type=MSSQL_METADATA objectRef=dbo.GetInspItemsCd locator=sys.objects
  - id=ev_metadata_7 type=MSSQL_METADATA objectRef=PEX_INSP_ITEMS locator=sys.sql_expression_dependencies
  - id=ev_metadata_8 type=MSSQL_METADATA objectRef=dbo.PEX_INSP_ITEMS locator=sys.objects,sys.schemas:referenced_id
  - id=ev_metadata_9 type=MSSQL_METADATA objectRef=dbo.PEX_INSP_ITEMS locator=sys.columns
  - id=static.analysis.migration_guide type=STATIC_ANALYSIS objectRef=dbo.GetInspItemsCd locator=analysis.migrationGuideStaticMetrics
- knownCaveats:
  - claimCode=RESULT_SHAPE_NEEDS_VERIFICATION claimType=risk status=evidence_caveat obligation=low_evidence_business_rule_claims evidenceRefs=metadata:dbo.GetInspItemsCd:sys.sql_modules, metadata:dbo.PEX_INSP_ITEMS:sys.columns
  - claimCode=PARAMETER_SEMANTIC_GAP claimType=risk status=evidence_caveat obligation=low_evidence_business_rule_claims evidenceRefs=metadata:dbo.GetInspItemsCd:sys.parameters, metadata:dbo.GetInspItemsCd:sys.sql_modules
  - claimCode=NORMALIZED_PROVIDER_RISKFLAGS_0 claimType=risk status=evidence_caveat obligation=low_evidence_business_rule_claims evidenceRefs=metadata:dbo.GetInspItemsCd:sys.sql_modules, metadata:dbo.PEX_INSP_ITEMS:sys.columns, metadata.procedureDefinitionHash
  - claimCode=NORMALIZED_PROVIDER_RISKFLAGS_1 claimType=risk status=evidence_caveat obligation=low_evidence_business_rule_claims evidenceRefs=metadata:dbo.GetInspItemsCd:sys.parameters, metadata:dbo.GetInspItemsCd:sys.sql_modules
  - claimCode=RESULT_SHAPE_UNCERTAIN claimType=risk status=evidence_caveat obligation=low_evidence_business_rule_claims evidenceRefs=metadata:dbo.GetInspItemsCd:sys.sql_modules, metadata:dbo.PEX_INSP_ITEMS:sys.columns, metadata.procedureDefinitionHash
  - claimCode=PARAMETER_CONTRACT_GAP claimType=risk status=evidence_caveat obligation=low_evidence_business_rule_claims evidenceRefs=metadata:dbo.GetInspItemsCd:sys.parameters, metadata:dbo.GetInspItemsCd:sys.sql_modules
  - claimCode=RESULT_SHAPE_UNCERTAINTY claimType=risk status=evidence_caveat obligation=low_evidence_business_rule_claims evidenceRefs=metadata:dbo.GetInspItemsCd:sys.sql_modules, metadata:dbo.PEX_INSP_ITEMS:sys.columns, metadata.procedureDefinitionHash
- 가정: 근거 보강 필요 근거 보강 필요: metadata는 MSSQL MCP registry 경계를 통해 수집되며 이 integration slice에서는 platform DB workflow repository에 저장됩니다.
- 가정: 근거 보강 필요 근거 보강 필요: LLM semantic analysis is inferred; treat it as an evidence caveat.
- 가정: 근거 보강 필요 Provider returned a structured assumption object; text was not stored.
- 가정: 근거 보강 필요 DETERMINISTIC_SAFETY_NET은 허용된 결정론적 fact id만 사용해 초안 claim을 추가했습니다.
- 가정: 근거 보강 필요 confirmed dependency procedure semantic outputs are draft-only evidence aids.

## quality_summary
- status: draft-quality evidence caveats tracked
- raw SQL text, row data, secrets, execution output은 포함하지 않습니다.

## evidence_map
- claims are tied to evidenceRefs or evidence caveats.

## known_caveats
- 근거 보강 필요는 근거 보강 필요 상태를 의미합니다.

## next_evidence_to_collect
- DML matrix, branch call-flow, transaction boundary, Java/MyBatis mapping evidence를 보강합니다.

## draft_readiness
- Ready as a migration-guide draft; no publish, deploy, DDL, DML, or source apply path is included.

## evidence_summary
- 저장 프로시저: `dbo.GetInspItemsCd`
- 테이블: `dbo.PEX_INSP_ITEMS`
- 의존성 근거: `dbo.GetInspItemsCd`
- 의존성 근거: `PEX_INSP_ITEMS`
- 의존성 근거: `dbo.PEX_INSP_ITEMS`
- LLM 추론: `3a0ef37e8c70b1fc8b496d9fd3352a820a1ca3c7ba6cb67d8d77d007eac44820`

## llm_risk_flags
- WARNING `RESULT_SHAPE_NEEDS_VERIFICATION`: 반환 컬럼 후보는 식별되지만 alias/타입 강제변환/nullable 정책의 계약 확정은 추가 검증이 필요합니다.
- WARNING `PARAMETER_SEMANTIC_GAP`: 입력 파라미터 정의와 실제 필터 적용 간 의미 불일치 가능성이 있어 API 시그니처 고정 전 검토가 필요합니다.
- WARNING `NORMALIZED_PROVIDER_RISKFLAGS_0`: 결과 컬럼 후보는 3개로 보이나 alias/타입 확정 정보가 부족하여 DTO 매핑 확정 전 검토가 필요합니다.
- WARNING `NORMALIZED_PROVIDER_RISKFLAGS_1`: 파라미터 정의와 실제 조회 조건 간 의미 불일치 가능성이 있어 Java/MyBatis 시그니처 확정 전 확인이 필요합니다.
- WARNING `RESULT_SHAPE_UNCERTAIN`: 반환 컬럼 후보는 식별되지만 alias/타입 강제 변환/nullable 정책 확정이 필요합니다.
- WARNING `PARAMETER_CONTRACT_GAP`: Java 메서드 시그니처 확정 전에 @InspItemsCd의 실제 사용 규칙 확인이 필요합니다.
- WARNING `RESULT_SHAPE_UNCERTAINTY`: 반환 컬럼 3개는 식별되지만 alias/타입 강제 변환 및 최종 매핑 계약은 추가 검증이 필요합니다.

## assumptions_and_todo
- TODO: nested procedure/function/view dependencies 확인
- TODO: read/write dependency direction 확정

## quality_summary
- evidence_included: true
- draft_only_boundary_marked: true
- dependency direction remains a caveat when resolver evidence is incomplete

## evidence_map
- 저장 프로시저: `dbo.GetInspItemsCd`
- 테이블: `dbo.PEX_INSP_ITEMS`
- 의존성 근거: `dbo.GetInspItemsCd`
- 의존성 근거: `PEX_INSP_ITEMS`
- 의존성 근거: `dbo.PEX_INSP_ITEMS`
- LLM 추론: `3a0ef37e8c70b1fc8b496d9fd3352a820a1ca3c7ba6cb67d8d77d007eac44820`

## known_caveats
- Evidence caveat items mean evidence needs to be strengthened.

## next_evidence_to_collect
- Confirm nested procedure/function/view dependencies and read/write direction.

## draft_readiness
- Ready as a draft dependency input; no execution or apply path is included.
