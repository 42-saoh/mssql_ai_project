# Draft artifacts for job_7f1635c8de

These files are draft outputs from the MSSQL Agent Portal.
They are sanitized artifact contents only and are not an execution, apply, deployment, or publication package.
